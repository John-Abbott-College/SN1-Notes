import turtle
import random
RADAR_INFINITY = 1000
TURTLE_SIZE = 20 # in pixels
OBSTACLE_SCALE = (2,2,2)
COLLISION_RADIUS = max(OBSTACLE_SCALE)*TURTLE_SIZE

# For typing hinting
Turtle = turtle.Turtle
def get_screen_size():
    screen = turtle.Screen()
    height = screen.window_height()
    width = screen.window_height()
    return -width//2,-height//2, width//2, height//2

def shape_robot(robot:Turtle):
    # Setting the robot shape
    turtle.Screen().register_shape('robot_shape.gif')
    robot.shape('robot_shape.gif')

def place_obstacles(robot:Turtle, num_obstacles:int = 10)->list[Turtle]:
    # Placing obstacles on the scene
    obstacles = [turtle.Turtle("square") for _ in range(num_obstacles)]
    x_min, y_min, x_max, y_max = get_screen_size()
    for obstacle in obstacles:
        obstacle.color("brown")
        obstacle.shapesize(*OBSTACLE_SCALE)

        x,y= random.randint(x_min,x_max), random.randint(y_min,y_max)
        while robot.distance(x,y) < COLLISION_RADIUS:
            x, y = random.randint(x_min, x_max), random.randint(y_min, y_max)
        obstacle.speed(0)
        obstacle.up()
        obstacle.goto(x,y)

    # Make sure at least one obstacle in front
    obstacles[0].goto(0, 100)
    obstacles[1].goto(150,0)
    obstacles[2].goto(-200,0)
    robot.forward(0) # draws  the robot on top
    return obstacles

def read_radar(robot:Turtle, obstacles:list[Turtle],direction:str)->float:
    robot_pos = robot.pos()

    distances = []
    for obstacle in obstacles:
        obs_pos = obstacle.pos()
        if direction == "forward": #check if x is same
            if abs(robot_pos[0]- obs_pos[0]) < COLLISION_RADIUS and obs_pos[1] > robot_pos[1]:
                distances.append(obs_pos[1] - robot_pos[1])
        elif direction == "right":
            # check if y is same and object is to the right
            if abs(robot_pos[1]- obs_pos[1]) < COLLISION_RADIUS and obs_pos[0] > robot_pos[0]:
                distances.append(obs_pos[0] - robot_pos[0])
        elif direction =="left":
            # check if y is same and object is to the left
            if abs(robot_pos[1]- obs_pos[1]) < COLLISION_RADIUS  and obs_pos[0] < robot_pos[0]:
                distances.append(abs(obs_pos[0] - robot_pos[0]))


    if distances:
        return min(distances)
    else:
        return RADAR_INFINITY

def collision_detected(robot:Turtle, obstacles:list[Turtle])->bool:
    for obstacle in obstacles:


        if robot.distance(obstacle) < COLLISION_RADIUS:
            return True

    return False

def animate_robot_coliision(robot:Turtle):
    for _ in range(5):
        robot.hideturtle()
        turtle.delay(5)
        robot.showturtle()