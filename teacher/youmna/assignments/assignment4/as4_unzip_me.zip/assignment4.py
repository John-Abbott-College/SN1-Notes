"""
Assignment 4
Name:
Section:
Date:
Description:
"""
from matplotlib import pyplot as plt

# ---------------------------------------------------------------
# Data: first ionization energies (eV) and single-bond covalent radii (pm,
# Pyykko) for elements 1-54, taken from the mendeleev Python package
# (L. Mentel, https://github.com/lmmentel/mendeleev, MIT License) and
# rounded for teaching use. Original literature references for each
# property are listed in the mendeleev documentation.
# ---------------------------------------------------------------
ELEMENTS = [
    'H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F',
    'Ne', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar',
    'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co',
    'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr',
    'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh',
    'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', 'Te', 'I', 'Xe'
]

ATOMIC_NUMBERS = [
    1, 2, 3, 4, 5, 6, 7, 8, 9,
    10, 11, 12, 13, 14, 15, 16, 17, 18,
    19, 20, 21, 22, 23, 24, 25, 26, 27,
    28, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 38, 39, 40, 41, 42, 43, 44, 45,
    46, 47, 48, 49, 50, 51, 52, 53, 54
]

# first ionization energies in eV
ION_ENERGIES = [
    13.6, 24.59, 5.39, 9.32, 8.3, 11.26, 14.53, 13.62, 17.42,
    21.56, 5.14, 7.65, 5.99, 8.15, 10.49, 10.36, 12.97, 15.76,
    4.34, 6.11, 6.56, 6.83, 6.75, 6.77, 7.43, 7.9, 7.88,
    7.64, 7.73, 9.39, 6.0, 7.9, 9.79, 9.75, 11.81, 14.0,
    4.18, 5.69, 6.22, 6.63, 6.76, 7.09, 7.12, 7.36, 7.46,
    8.34, 7.58, 8.99, 5.79, 7.34, 8.61, 9.01, 10.45, 12.13
]

# covalent radii in pm
RADII = [
    32, 46, 133, 102, 85, 75, 71, 63, 64,
    67, 155, 139, 126, 116, 111, 103, 99, 96,
    196, 171, 148, 136, 134, 122, 119, 116, 111,
    110, 112, 118, 124, 121, 121, 116, 114, 117,
    210, 185, 163, 154, 147, 138, 128, 125, 125,
    120, 128, 136, 142, 140, 140, 136, 133, 131
]

# Groups
NOBLE_GASES = ['He', 'Ne', 'Ar', 'Kr', 'Xe']
ALKALI_METALS = ['Li', 'Na', 'K', 'Rb']
HALOGENS = ['F', 'Cl', 'Br', 'I']


# ---------------------------------------------------------------
# TODO: Add your functions here:
# ---------------------------------------------------------------











# ---------------------------------------------------------------
# TODO: Call your functions in the main below
# ---------------------------------------------------------------
def main():
    print("Call your functions here")






# ---------------------------------------------------------------
# DO NOT REMOVE THE LINES BELOW THIS LINE
# ---------------------------------------------------------------
if __name__ == "__main__":
    main()
