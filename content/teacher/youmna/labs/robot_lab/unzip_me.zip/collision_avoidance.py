import turtle
from collision_helper import *

NUM_OBSTACLES = 20
LIMIT = 100
ROBOT_SPEED = 50


X_MIN, Y_MIN, X_MAX, Y_MAX = get_screen_size()

def move(x,y,front_radar,right_radar,left_radar):
    # TODO: Add better decision making
    new_x = x
    new_y = y+1


    return new_x, new_y

def main():
    robot = turtle.Turtle()
    shape_robot(robot)
    obstacles = place_obstacles(robot=robot, num_obstacles= NUM_OBSTACLES)

    x,y = robot.pos()

    # TODO: 1. Repeat those steps in a loop as long as the robot's x position
    #  is between [X_MIN, X_MAX] and its y position is between [Y_MIN, Y_MAX]
    # TODO: 2. If a collision is detected interrupt the loop (break)
    front_radar = read_radar(robot, obstacles, "forward")
    right_radar = read_radar(robot, obstacles, "right")
    left_radar = read_radar(robot, obstacles, "left")
    print(f"front: {front_radar}, right: {right_radar}, left: {left_radar}")
    x, y = move(x,y, front_radar,left_radar, right_radar)
    if collision_detected(robot, obstacles):
        print("Collision detected!")

    # TODO: 3. After the loop, print a success message
    #  if the robot reached the edge of the screen


if __name__ =="__main__":
    main()
    turtle.mainloop()