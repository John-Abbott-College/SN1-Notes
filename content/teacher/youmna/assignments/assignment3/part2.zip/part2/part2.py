"""
Assignment 3 - Part 2
Name:
Section:
Date:
Description: Main Program for Part 2.
"""
import csv
from my_functions import *

SAMPLING_RATE:float = 100
FILENAME:str  = 'ecg.csv'



def convert_to_floats(row:list[str])-> list[float]:
    """
     Convert a list of numeric strings to a list of floats.

     Args:
         row: Values read from one CSV row, e.g. ['0.12', '-0.05', '1.3'].

     Returns:
         The same values as floats, in the same order.
     """
    list_floats = []
    for val in row:
        list_floats.append(float(val))
    return list_floats

def read_data(csv_filename:str)->list[float]:
    """
     Read one ECG recording (one row) from a CSV file.

     Each row of the file is one ECG recording, stored as comma-separated
     voltage values in mV.

     Args:
         csv_filename: Path to the CSV file to read.

     Returns:
         The ECG values from that row as floats. Returns an empty list if
         the file has fewer than row_index + 1 rows.
     """
    raw_ecg = []
    with open(csv_filename, 'r') as file:
        reader = csv.reader(file)
        line_str = next(reader)
        raw_ecg = convert_to_floats(line_str)
    return raw_ecg



def main():
    ecg = read_data(FILENAME)
    time = [] # TODO: Replace this and call your create_time_axis() function

    # TODO: Call plot_ecg() and save it under part2_ecg.png


    # TODO: Call find_r_peaks() to find all the peaks


    # TODO: Call plot_ecg_with_peaks() to visualize the R peaks on the graph
    # TODO: Save the graph under part2_ecg_with_peaks.png

    # TODO: Calculate the heart rate


if __name__ =='__main__':
    main()